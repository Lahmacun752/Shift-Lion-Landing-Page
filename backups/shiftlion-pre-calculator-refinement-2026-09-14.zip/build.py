from pathlib import Path
import json, shutil, html, re

ROOT = Path(__file__).parent
SRC = ROOT / "src" / "pages"
STATIC = ROOT / "static"
OUT = ROOT / "hosting"
CONFIG = json.loads((ROOT / "site.json").read_text(encoding="utf-8"))

TOOL_PAGES = {
    "arbeitszeitrechner.html", "nachtzuschlag-rechner.html",
    "ueberstunden-rechner.html", "stundenlohn-rechner.html",
    "arbeitstage-rechner.html", "feiertagszuschlag-rechner.html",
    "schichten-vergleichen.html", "schichtplaner-online.html",
    "schichtzulagen-rechner.html", "working-time-calculator.html",
    "night-allowance-calculator.html", "overtime-calculator.html",
    "hourly-wage-calculator.html", "workdays-calculator.html",
    "holiday-allowance-calculator.html", "compare-shifts.html",
}


def render_nav(css_class="nav", tag="nav"):
    links = []
    for item in CONFIG["navigation_de"]:
        href = html.escape(item["href"], quote=True)
        label = html.escape(item["label"])
        links.append(f'  <a href="{href}">{label}</a>')
    return f'<{tag} class="{css_class}">\n' + "\n".join(links) + f'\n</{tag}>'


def build():
    if OUT.exists():
        shutil.rmtree(OUT)
    shutil.copytree(STATIC, OUT)

    for source in SRC.rglob("*.html"):
        rel = source.relative_to(SRC)
        target = OUT / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        text = source.read_text(encoding="utf-8")
        text = text.replace("{{NAV_DE}}", render_nav("nav", "nav"))
        text = text.replace("{{NAV_DE_DARK}}", render_nav("nav nav-dark", "div"))
        text = re.sub(r'/workdays-calculator\.js(?:\?v=\d+)?"', '/workdays-calculator.js?v=9"', text)
        text = text.replace('/calculator-tools.css"', '/calculator-tools.css?v=2"')
        text = re.sub(r'/tool-hub\.js(?:\?v=\d+)?"', '/tool-hub.js?v=10"', text)
        if source.name in TOOL_PAGES or (
            source.name in {"schichtplaner-online.html", "schichtzulagen-rechner.html"}
            and rel.parts and rel.parts[0] == "en"
        ):
            text = re.sub(
                r"</head>",
                '<link rel="stylesheet" href="/tool-foundation.css?v=2"></head>',
                text,
                count=1,
                flags=re.I,
            )
            # Some tools contain printable HTML inside JavaScript template
            # strings. Inject at the real page end, never at an inner </body>.
            body_end = text.lower().rfind("</body>")
            if body_end != -1:
                text = (
                    text[:body_end]
                    + '<script src="/tool-foundation.js?v=2"></script>'
                    + text[body_end:]
                )
        target.write_text(text, encoding="utf-8")

    # Keep the English homepage visually identical to the German homepage.
    german_home = (SRC / "index.html").read_text(encoding="utf-8")
    style_match = re.search(r"<style>(.*?)</style>", german_home, re.S)
    if style_match:
        (OUT / "en" / "homepage-structure.css").write_text(style_match.group(1), encoding="utf-8")

    # Sitemap from the same config: no manual sitemap maintenance.
    urls = []
    for item in CONFIG["navigation_de"]:
        if item.get("sitemap"):
            urls.append(item["href"])
    urls.extend(CONFIG.get("extra_sitemap", []))

    base = CONFIG["site_url"].rstrip("/")
    lines = ['<?xml version="1.0" encoding="UTF-8"?>', '',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    seen = set()
    for path in urls:
        if path in seen:
            continue
        seen.add(path)
        url = base + (path if path.startswith("/") else "/" + path)
        if path == "/":
            url = base + "/"
        lines += ["", "  <url>", f"    <loc>{html.escape(url)}</loc>", "  </url>"]
    lines += ["", "</urlset>", ""]
    (OUT / "sitemap.xml").write_text("\n".join(lines), encoding="utf-8")

    print(f"Build fertig: {OUT}")
    print(f"Seiten in Sitemap: {len(seen)}")

if __name__ == "__main__":
    build()
